package com.example.minni.myapplication;

import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class Activity6 extends AppCompatActivity {
    DatabaseHelper myDb2;
    Button b11;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);
        myDb2=new DatabaseHelper(this);
        b11=(Button)findViewById(R.id.butt1);

        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res=myDb2.getAllData();
                if(res.getCount()==0)
                {
                    showMessage("ERROR","NOTHING FOUND");
                    return;
                }
                StringBuffer buffer =new StringBuffer();
                while(res.moveToNext())
                {
                    buffer.append("Id :"+ res.getString(0)+"\n");
                    buffer.append("NAME :"+ res.getString(1)+"\n");
                    buffer.append("MOBILE :"+ res.getString(2)+"\n");
                    buffer.append("ADDRESS :"+ res.getString(3)+"\n");
                    buffer.append("REQUIRED :"+ res.getString(4)+"\n");

                }
                showMessage("Data",buffer.toString());


            }
        });

    }
    public void showMessage(String title,String Message)
    {
        AlertDialog.Builder builder =new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}
